
<strong>Copyright &copy; 2016 - <?php echo date('Y'); ?> <a target='_BLANK' href="http://www.lokomedia.web.id"> Lokomedia.web.id</a>.</strong> All rights reserved. 