<div class="container">
	<br/>
	<h2>Galeri</h2>
	<div class="row">
		<div class="masonry-loader masonry-loader-loaded">
			<div class="resp-container" style="position: relative; overflow: hidden; padding-top: 56.25%;">
				<iframe class="resp-iframe" src="<?php echo base_url();?>albums/frame/<?php echo $this->uri->segment(3); ?>" gesture="media" allow="encrypted-media" allowfullscreen frameBorder="0" style="position:absolute;top:0; left: 0; width: 100%; height: 100%; border: 0;"></iframe>
			</div>
			
		
		
			<div class="bounce-loader"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div>
		</div>
	</div>

</div>
	
	
	
